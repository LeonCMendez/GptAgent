# Reflexões

Arquivo para reflexões de longo prazo sobre negócios, liderança, inovação e aprendizados pessoais. Use este espaço para registrar ideias e pensamentos que não se encaixam nos briefs diários.

## TODO

- Anotar reflexões e insights importantes à medida que surgirem.