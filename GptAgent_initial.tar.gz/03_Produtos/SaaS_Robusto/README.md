# SaaS Robusto

Espaço para projetos de software como serviço mais robustos, que exigem arquitetura escalável e manutenção contínua.

## TODO

- Registrar ideias de produtos SaaS.
- Documentar requisitos, funcionalidades e roadmap.