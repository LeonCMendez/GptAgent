# Inspirações e Referências

Este diretório reúne referências de design, artigos, frameworks e recursos que inspiram o desenvolvimento de produtos da MicroFábrica.

## TODO

- Adicionar links, anotações e materiais de referência úteis.