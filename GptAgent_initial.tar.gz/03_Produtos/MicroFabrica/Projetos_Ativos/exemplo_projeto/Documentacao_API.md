# Documentação da API — exemplo_projeto

Aqui será construída a documentação da API para o projeto `exemplo_projeto`. Defina endpoints, métodos, parâmetros e exemplos de resposta.

## Endpoints

- TODO: listar endpoints, métodos HTTP e descrições.

## Esquemas de Dados

- TODO: definir modelos de dados utilizados nas requisições e respostas.