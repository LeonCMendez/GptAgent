# Board — exemplo_projeto

## Backlog
- TODO: listar tarefas pendentes.

## Em Desenvolvimento
- TODO: listar tarefas em andamento.

## Revisão
- TODO: listar tarefas em revisão.

## Concluído
- TODO: listar tarefas concluídas.