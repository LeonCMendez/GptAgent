# Estrutura Organizacional

Este documento descreve a estrutura hierárquica da empresa, cargos, papéis e relações de reporte. Manter este organograma atualizado é essencial para clareza e alinhamento interno.

## Organograma

TODO: desenhar o organograma da empresa, listando departamentos e posições.

## Responsabilidades

TODO: detalhar as responsabilidades de cada área e cargo.