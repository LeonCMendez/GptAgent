# Planejamento Financeiro

Centraliza o planejamento financeiro anual e trimestral. Use este espaço para elaborar projeções de receitas, despesas e investimentos.

## TODO

- Criar forecast de receitas e despesas.
- Definir metas de crescimento e margens desejadas.