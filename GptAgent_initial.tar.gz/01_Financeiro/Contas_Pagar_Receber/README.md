# Contas a Pagar e Receber

Controle de fluxo de caixa e registros de contas a pagar e a receber. Mantenha este diretório organizado com planilhas ou documentos pertinentes.

## TODO

- Incluir planilha de pagamentos recorrentes.
- Registrar recebíveis e datas de vencimento.