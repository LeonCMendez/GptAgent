# Reuniões do Leon

Este diretório armazena atas e notas de reuniões realizadas pelo Leon. Organize os arquivos utilizando o formato `YYYY-MM-DD.md` para facilitar a localização.

## TODO

- Registrar atas de reuniões com data e participantes.