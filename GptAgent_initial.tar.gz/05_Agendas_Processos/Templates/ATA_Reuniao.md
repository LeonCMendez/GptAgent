# Template de ATA de Reunião

Utilize este template para registrar as atas de reunião de forma padronizada.

## Informações Básicas

- **Data:** YYYY-MM-DD
- **Participantes:** Lista de participantes
- **Agenda:** Tópicos discutidos

## Discussões e Decisões

- **Item 1:** Descrição das discussões e decisões tomadas.
- **Item 2:** Descrição das discussões e decisões tomadas.

## Ações

- [ ] **Responsável** — Descrição da ação (prazo)
- [ ] **Responsável** — Descrição da ação (prazo)