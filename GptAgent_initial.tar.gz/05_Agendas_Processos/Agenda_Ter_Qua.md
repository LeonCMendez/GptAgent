# Agenda — Terça e Quarta

Disponibilidade fixa do Leon nas terças e quartas. Esta agenda serve como referência para marcação de compromissos recorrentes.

## Terça‑feira

TODO: definir blocos de horário disponíveis.

## Quarta‑feira

TODO: definir blocos de horário disponíveis.