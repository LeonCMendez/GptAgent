# GptAgent — Gestão Integrada

Bem‑vindo ao repositório **GptAgent**. Este projeto serve como o ponto único de verdade para a gestão de todas as frentes da empresa comandada pelo Leon. A estrutura foi desenhada para ser simples, extensível e permitir que qualquer informação seja localizada em, no máximo, dois cliques.

## Estrutura do repositório

* `00_Governanca/` – Documentos de governança corporativa. Aqui residem a **Visão, Missão e Valores** da empresa, a **Estrutura Organizacional** e as **Políticas de Segurança**. Estes documentos guiam todas as decisões estratégicas.
* `01_Financeiro/` – Contém o planejamento financeiro, o controle de contas a pagar/receber e relatórios mensais. Cada subdiretório possui um arquivo `README.md` descrevendo como organizar as informações.
* `02_Marketing/` – Guarda o plano de marketing, calendário de conteúdo e relatórios de performance. Estes documentos orientarão todas as iniciativas de marketing.
* `03_Produtos/` – Abriga as iniciativas de produto, divididas entre **MicroFábrica** (projetos menores, experimentais) e **SaaS Robusto** (soluções mais completas). Dentro de `Projetos_Ativos` cada projeto tem seu próprio *Board* de tarefas e documentação específica.
* `04_Pessoal_Leon/` – Espaço pessoal do Leon. Inclui o **Diário Estratégico**, onde serão registrados briefs diários, e um arquivo de **Reflexões** de longo prazo.
* `05_Agendas_Processos/` – Contém agendas e processos recorrentes, como a agenda semanal de disponibilidade, reuniões e templates de atas.

## Como contribuir

Este repositório é de uso exclusivo do Leon. Todas as contribuições devem seguir as seguintes convenções:

1. **Commits atômicos:** cada alteração deve ter um único propósito claro.
2. **Mensagens em PT‑BR:** descreva o que foi feito de forma concisa, por exemplo `feat: criar planejamento financeiro inicial`.
3. **Branches nomeadas:** use prefixos `feat/…`, `fix/…`, `doc/…` conforme a natureza da mudança.
4. **Pull Requests:** mesmo sendo um repositório de usuário único, utilize PRs para manter disciplina de revisão.

Sinta‑se à vontade para expandir esta estrutura conforme as necessidades de gestão evoluírem.